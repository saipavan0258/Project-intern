import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stadium-main',
  templateUrl: './stadium-main.component.html',
  styleUrls: ['./stadium-main.component.css']
})
export class StadiumMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
