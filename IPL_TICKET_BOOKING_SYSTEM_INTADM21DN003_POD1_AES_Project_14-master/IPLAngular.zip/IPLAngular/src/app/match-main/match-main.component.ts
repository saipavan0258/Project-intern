import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-match-main',
  templateUrl: './match-main.component.html',
  styleUrls: ['./match-main.component.css']
})
export class MatchMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
